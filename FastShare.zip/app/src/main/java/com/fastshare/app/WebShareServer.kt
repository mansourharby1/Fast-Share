package com.fastshare.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder

/** Tiny HTTP server so any phone/PC with a browser can download the picked files over Wi-Fi / hotspot. */
class WebShareServer(
    private val ctx: Context,
    private val files: List<Uri>,
    private val token: String
) {
    var port = 0
    var onEvent: ((String) -> Unit)? = null

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private val names = files.map { nameOf(it) }
    private val sizes = files.map { sizeOf(it) }

    fun start(): Boolean {
        for (p in 8080..8099) {
            try { server = ServerSocket(p); port = p; break } catch (_: Exception) {}
        }
        val s = server ?: return false
        running = true
        Thread {
            while (running) {
                try {
                    val c = s.accept()
                    Thread { handle(c) }.start()
                } catch (_: Exception) { break }
            }
        }.start()
        return true
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
    }

    private fun handle(sock: Socket) {
        sock.use {
            try {
                sock.soTimeout = 15000
                val reader = sock.getInputStream().bufferedReader()
                val line = reader.readLine() ?: return
                while (true) {
                    val h = reader.readLine() ?: break
                    if (h.isEmpty()) break
                }
                val parts = line.split(" ")
                if (parts.size < 2) return
                val path = parts[1].substringBefore('?')
                val out = sock.getOutputStream()
                val prefix = "/$token"
                if (!path.startsWith(prefix)) { respond(out, 403, "text/plain", "Forbidden".toByteArray()); return }
                val rest = path.removePrefix(prefix)
                if (rest == "" || rest == "/") {
                    respond(out, 200, "text/html; charset=utf-8", page().toByteArray(Charsets.UTF_8))
                } else if (rest.startsWith("/f/")) {
                    val i = rest.removePrefix("/f/").toIntOrNull()
                    if (i == null || i !in files.indices) respond(out, 404, "text/plain", "Not found".toByteArray())
                    else sendFile(out, i)
                } else respond(out, 404, "text/plain", "Not found".toByteArray())
            } catch (_: Exception) {}
        }
    }

    private fun sendFile(out: OutputStream, i: Int) {
        val ins = ctx.contentResolver.openInputStream(files[i])
        if (ins == null) { respond(out, 404, "text/plain", "Not found".toByteArray()); return }
        val name = names[i]
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        val sb = StringBuilder("HTTP/1.1 200 OK\r\nContent-Type: $mime\r\n")
        sb.append("Content-Disposition: attachment; filename*=UTF-8''$enc\r\n")
        if (sizes[i] >= 0) sb.append("Content-Length: ${sizes[i]}\r\n")
        sb.append("Connection: close\r\n\r\n")
        onEvent?.invoke("📥 جاري تحميل: $name")
        out.write(sb.toString().toByteArray())
        ins.use { it.copyTo(out, 1 shl 16) }
        out.flush()
        onEvent?.invoke("✅ تم تحميل: $name")
    }

    private fun respond(out: OutputStream, code: Int, type: String, body: ByteArray) {
        val st = when (code) { 200 -> "OK"; 403 -> "Forbidden"; else -> "Not Found" }
        out.write("HTTP/1.1 $code $st\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(body)
        out.flush()
    }

    private fun page(): String {
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html dir=\"rtl\" lang=\"ar\"><head><meta charset=\"utf-8\">")
        sb.append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Fast Share</title><style>")
        sb.append("body{margin:0;font-family:sans-serif;background:#fff;color:#0D47A1}")
        sb.append("header{background:linear-gradient(135deg,#0D47A1,#1E88E5);color:#fff;padding:24px;border-radius:0 0 28px 28px}")
        sb.append("h1{margin:0 0 6px;font-size:26px}")
        sb.append("a.f{display:block;margin:12px 16px;padding:14px;background:#E3F0FF;border-radius:14px;color:#0D47A1;text-decoration:none;font-weight:bold;word-break:break-all}")
        sb.append("a.f small{display:block;color:#555;font-weight:normal;margin-top:4px}")
        sb.append("</style></head><body><header><h1>⚡ Fast Share</h1><div>اضغط على أي ملف لتحميله</div></header>")
        for ((i, n) in names.withIndex()) {
            sb.append("<a class=\"f\" href=\"/$token/f/$i\">⬇ ${esc(n)}<small>${fmt(sizes[i])}</small></a>")
        }
        sb.append("</body></html>")
        return sb.toString()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun fmt(b: Long): String = when {
        b < 0 -> ""
        b < 1048576 -> String.format("%.0f KB", b / 1024.0)
        else -> String.format("%.1f MB", b / 1048576.0)
    }

    private fun nameOf(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "file"
    }

    private fun sizeOf(uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
            }
        } catch (_: Exception) {}
        return -1
    }

    companion object {
        /** Wi-Fi / hotspot address of this phone, or null if not on a local network. */
        fun localIp(): String? {
            val found = ArrayList<Pair<String, String>>()
            try {
                for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (a in ni.inetAddresses.toList()) {
                        if (a is Inet4Address && a.isSiteLocalAddress) found.add(ni.name to (a.hostAddress ?: ""))
                    }
                }
            } catch (_: Exception) {}
            val wifi = found.firstOrNull { (n, _) ->
                n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.contains("p2p")
            }
            return (wifi ?: found.firstOrNull())?.second?.takeIf { it.isNotEmpty() }
        }
    }
}
