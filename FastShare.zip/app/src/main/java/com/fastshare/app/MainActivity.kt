package com.fastshare.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.IntentCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private val serviceId = "com.fastshare.app.SERVICE"
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private lateinit var client: ConnectionsClient

    private lateinit var tvFiles: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var progress: ProgressBar
    private lateinit var swClose: MaterialSwitch

    private val picked = mutableListOf<Uri>()
    private var peer: String? = null
    private var isSender = false
    private var asking = false

    // sender state
    private val sentIds = HashSet<Long>()
    private var sentDone = 0

    // receiver state
    private val names = HashMap<Long, String>()
    private val incoming = HashMap<Long, Payload>()
    private val completed = HashSet<Long>()
    private var expectedTotal = -1
    private var savedCount = 0

    // speed
    private val bytesById = HashMap<Long, Long>()
    private val totalById = HashMap<Long, Long>()
    private var startTime = 0L

    private var pendingAction: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (requiredPerms().all { granted(it) }) pendingAction?.invoke()
            else toast("لازم تسمح بكل الأذونات علشان النقل يشتغل")
            pendingAction = null
        }

    private val btEnableLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            pendingAction?.invoke()
            pendingAction = null
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                picked.clear(); picked.addAll(uris); refreshFiles()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        client = Nearby.getConnectionsClient(this)

        tvFiles = findViewById(R.id.tvFiles)
        tvStatus = findViewById(R.id.tvStatus)
        tvSpeed = findViewById(R.id.tvSpeed)
        progress = findViewById(R.id.progress)
        swClose = findViewById(R.id.swClose)

        findViewById<MaterialButton>(R.id.btnPick).setOnClickListener { pickLauncher.launch(arrayOf("*/*")) }
        findViewById<MaterialButton>(R.id.btnSend).setOnClickListener {
            if (picked.isEmpty()) toast("اختار ملفات الأول") else prepare { startSend() }
        }
        findViewById<MaterialButton>(R.id.btnReceive).setOnClickListener { prepare { startReceive() } }
        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener { stopAll(); status("تم الإيقاف") }
        findViewById<MaterialButton>(R.id.btnShareit).setOnClickListener { sendViaShareit() }

        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    // ---------- share-sheet input ----------
    private fun handleIncomingIntent(i: Intent?) {
        i ?: return
        val list = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { list.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { list.addAll(it) }
        }
        if (list.isNotEmpty()) {
            picked.clear(); picked.addAll(list); refreshFiles()
        }
    }

    private fun refreshFiles() {
        tvFiles.text = if (picked.isEmpty()) "لم يتم اختيار ملفات بعد"
        else "تم اختيار ${picked.size} ملف:\n" + picked.take(5).joinToString("\n") { "• " + displayName(it) } +
                if (picked.size > 5) "\n..." else ""
    }

    // ---------- permissions & radios ----------
    private fun requiredPerms(): List<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN
            l += Manifest.permission.BLUETOOTH_ADVERTISE
            l += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            l += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.NEARBY_WIFI_DEVICES
        return l
    }

    private fun granted(p: String) =
        ActivityCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun btAdapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    /** permissions -> bluetooth on -> wifi on -> action */
    private fun prepare(action: () -> Unit) {
        val missing = requiredPerms().filter { !granted(it) }
        if (missing.isNotEmpty()) {
            pendingAction = { prepare(action) }
            permLauncher.launch(missing.toTypedArray())
            return
        }
        val bt = btAdapter()
        if (bt != null && !bt.isEnabled) {
            pendingAction = { prepare(action) }
            btEnableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        if (!wifi.isWifiEnabled) {
            toast("شغّل الواي فاي ثم اضغط مرة أخرى")
            startActivity(Intent(Settings.Panel.ACTION_WIFI))
            return
        }
        action()
    }

    // ---------- start roles ----------
    private fun resetState() {
        sentIds.clear(); sentDone = 0
        names.clear(); incoming.clear(); completed.clear()
        expectedTotal = -1; savedCount = 0
        bytesById.clear(); totalById.clear()
        startTime = SystemClock.elapsedRealtime()
        progress.progress = 0
        tvSpeed.text = "0% • 0 MB/s"
        peer = null; asking = false
    }

    private fun startSend() {
        stopAll(); resetState(); isSender = true
        status("🔎 جاري البحث عن جهاز مستقبل قريب...")
        client.startDiscovery(
            serviceId, discoveryCb,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { status("فشل البحث: ${it.message}") }
    }

    private fun startReceive() {
        stopAll(); resetState(); isSender = false
        status("📡 جاهز للاستقبال... خلي المرسل يضغط إرسال")
        client.startAdvertising(
            Build.MODEL ?: "Android", serviceId, connCb,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { status("فشل الاستقبال: ${it.message}") }
    }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            if (peer != null || asking) return
            asking = true
            AlertDialog.Builder(this@MainActivity)
                .setTitle("تم العثور على جهاز")
                .setMessage("الاتصال بـ ${info.endpointName}؟")
                .setCancelable(false)
                .setPositiveButton("اتصال") { _, _ ->
                    client.requestConnection(Build.MODEL ?: "Android", id, connCb)
                        .addOnFailureListener { status("فشل الاتصال: ${it.message}"); asking = false }
                }
                .setNegativeButton("تجاهل") { _, _ -> asking = false }
                .show()
        }

        override fun onEndpointLost(id: String) {}
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("طلب اتصال من ${info.endpointName}")
                .setMessage("رمز التأكيد: ${info.authenticationDigits}\nتأكد إنه نفس الرمز على الجهاز الثاني.")
                .setCancelable(false)
                .setPositiveButton("قبول") { _, _ -> client.acceptConnection(id, payloadCb) }
                .setNegativeButton("رفض") { _, _ -> client.rejectConnection(id); asking = false }
                .show()
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            asking = false
            if (result.status.isSuccess) {
                peer = id
                client.stopDiscovery(); client.stopAdvertising()
                startTime = SystemClock.elapsedRealtime()
                if (isSender) sendAll() else status("✅ تم الاتصال... في انتظار الملفات")
            } else status("❌ تم رفض الاتصال أو فشل")
        }

        override fun onDisconnected(id: String) {
            if (peer == id) peer = null
        }
    }

    // ---------- sending ----------
    private fun sendAll() {
        val p = peer ?: return
        status("🚀 جاري الإرسال...")
        client.sendPayload(p, Payload.fromBytes("TOTAL:${picked.size}".toByteArray()))
        for (uri in picked) {
            val pfd = try { contentResolver.openFileDescriptor(uri, "r") } catch (e: Exception) { null } ?: continue
            val payload = Payload.fromFile(pfd)
            sentIds.add(payload.id)
            client.sendPayload(p, Payload.fromBytes("${payload.id}:${displayName(uri)}".toByteArray()))
            client.sendPayload(p, payload)
        }
        if (sentIds.isEmpty()) { status("مفيش ملفات صالحة للإرسال"); stopAll() }
    }

    // ---------- payload handling ----------
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val s = String(payload.asBytes() ?: return)
                    if (s.startsWith("TOTAL:")) {
                        expectedTotal = s.removePrefix("TOTAL:").toIntOrNull() ?: -1
                    } else {
                        val i = s.indexOf(':')
                        if (i > 0) {
                            val pid = s.substring(0, i).toLongOrNull() ?: return
                            names[pid] = s.substring(i + 1)
                            trySave(pid)
                        }
                    }
                }
                Payload.Type.FILE -> incoming[payload.id] = payload
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val pid = u.payloadId
            val isFile = sentIds.contains(pid) || incoming.containsKey(pid)
            if (isFile && u.totalBytes > 0) {
                bytesById[pid] = u.bytesTransferred
                totalById[pid] = u.totalBytes
                updateProgress()
            }
            if (u.status == PayloadTransferUpdate.Status.FAILURE) {
                status("❌ فشل نقل ملف"); return
            }
            if (u.status != PayloadTransferUpdate.Status.SUCCESS) return
            if (sentIds.contains(pid)) {
                sentDone++
                if (sentDone >= sentIds.size) {
                    status("✅ تم إرسال كل الملفات")
                    tvSpeed.postDelayed({ finishAndClose() }, 1500)
                }
            } else if (incoming.containsKey(pid)) {
                completed.add(pid)
                trySave(pid)
            }
        }
    }

    private fun updateProgress() {
        val done = bytesById.values.sum()
        val total = totalById.values.sum()
        if (total <= 0) return
        val pct = (done * 100 / total).toInt()
        val sec = (SystemClock.elapsedRealtime() - startTime).coerceAtLeast(1) / 1000.0
        val mbps = done / 1048576.0 / sec
        progress.progress = pct
        tvSpeed.text = String.format("%d%% • %.1f MB/s", pct, mbps)
    }

    // ---------- saving (receiver) ----------
    private fun trySave(pid: Long) {
        val p = incoming[pid] ?: return
        val name = names[pid] ?: return
        if (!completed.contains(pid)) return
        incoming.remove(pid)
        Thread {
            val ok = saveToDownloads(p, name)
            runOnUiThread {
                savedCount++
                status(if (ok) "💾 تم حفظ: $name" else "⚠ تعذر حفظ: $name")
                if (expectedTotal > 0 && savedCount >= expectedTotal) {
                    status("✅ تم استقبال $savedCount ملف في Downloads/FastShare")
                    finishAndClose()
                }
            }
        }.start()
    }

    private fun saveToDownloads(p: Payload, name: String): Boolean {
        return try {
            val src = p.asFile()?.asUri() ?: return false
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FastShare")
            }
            val dst = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            contentResolver.openInputStream(src).use { i ->
                contentResolver.openOutputStream(dst).use { o ->
                    if (i == null || o == null) return false
                    i.copyTo(o, 1 shl 16)
                }
            }
            try { contentResolver.delete(src, null, null) } catch (_: Exception) {}
            true
        } catch (e: Exception) { false }
    }

    // ---------- finish: stop Nearby + close radios ----------
    private fun stopAll() {
        try {
            client.stopDiscovery(); client.stopAdvertising(); client.stopAllEndpoints()
        } catch (_: Exception) {}
        peer = null
    }

    private fun finishAndClose() {
        stopAll()
        if (swClose.isChecked) closeRadios()
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun closeRadios() {
        var btClosed = false
        try {
            if (Build.VERSION.SDK_INT < 33) btClosed = btAdapter()?.disable() == true
        } catch (_: Exception) {}
        // Android 10+ does not let apps switch Wi-Fi off directly, so open the system panel
        AlertDialog.Builder(this)
            .setTitle("انتهى النقل ✅")
            .setMessage(
                (if (btClosed) "تم إغلاق البلوتوث.\n" else "أندرويد 13+ لا يسمح للتطبيقات بإغلاق البلوتوث تلقائياً.\n") +
                        "اضغط لإغلاق الواي فاي والبلوتوث من إعدادات النظام."
            )
            .setPositiveButton("إغلاق الواي فاي") { _, _ -> startActivity(Intent(Settings.Panel.ACTION_WIFI)) }
            .setNeutralButton("البلوتوث") { _, _ -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            .setNegativeButton("لاحقاً", null)
            .show()
    }

    // ---------- SHAREit hand-off ----------
    private fun sendViaShareit() {
        if (picked.isEmpty()) { toast("اختار ملفات الأول"); return }
        val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(picked))
            setPackage("com.lenovo.anyshare.gps")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(i) } catch (e: ActivityNotFoundException) { toast("SHAREit غير مثبت على الجهاز") }
    }

    // ---------- helpers ----------
    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "file"
    }

    private fun status(s: String) = runOnUiThread { tvStatus.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
